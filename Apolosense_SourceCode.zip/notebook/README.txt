Please place your exported ApoloSense.ipynb file here before final submission.
Go to File -> Download -> Download .ipynb in Colab.