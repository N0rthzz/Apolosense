# ApoloSense: Thai Apology Sincerity Detection

Project structure for sincerity detection using Ensemble Learning and Handcrafted Features.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
- To train the model: `python src/train.py`
- To test prediction: `python src/predict.py`

## Dataset Sources

1) Custom Dataset
- data/apology_mock_1000.csv

2) External Thai Sentiment Dataset
- https://raw.githubusercontent.com/PyThaiNLP/wisesight-sentiment/master/kaggle-competition/train.txt
- https://raw.githubusercontent.com/PyThaiNLP/wisesight-sentiment/master/kaggle-competition/train_label.txt