import pandas as pd
import numpy as np
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.ensemble import VotingClassifier
from pythainlp.tokenize import word_tokenize

def tokenize(text):
    return word_tokenize(text, engine='newmm')

def train():
    df_mock = pd.read_csv('data/apology_mock_1000.csv')
    df_mock['label'] = df_mock['label'].map({'จริงใจ': 1, 'ไม่จริงใจ': 0}) if df_mock['label'].dtype == object else df_mock['label']
    
    t_url = "https://raw.githubusercontent.com/PyThaiNLP/wisesight-sentiment/master/kaggle-competition/train.txt"
    l_url = "https://raw.githubusercontent.com/PyThaiNLP/wisesight-sentiment/master/kaggle-competition/train_label.txt"
    texts = pd.read_table(t_url, header=None, names=['text'])
    labels = pd.read_table(l_url, header=None, names=['label'])
    df_thai = pd.concat([texts, labels], axis=1)
    df_thai = df_thai[df_thai['label'].isin(['pos', 'neg'])]
    df_thai['label'] = df_thai['label'].map({'pos': 1, 'neg': 0})
    
    df = pd.concat([df_mock, df_thai]).sample(frac=1, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(df['text'], df['label'], test_size=0.2, random_state=42)
    
    vectorizer = TfidfVectorizer(tokenizer=tokenize, max_features=5000)
    X_train_vec = vectorizer.fit_transform(X_train)
    
    model = VotingClassifier(estimators=[
        ('lr', LogisticRegression(max_iter=1000)), 
        ('nb', MultinomialNB()), 
        ('svm', LinearSVC())
    ], voting='hard')
    model.fit(X_train_vec, y_train)
    
    joblib.dump(model, 'models/apolosense_model.pkl')
    joblib.dump(vectorizer, 'models/vectorizer.pkl')
    print('Training Complete using 5000 TF-IDF features.')

if __name__ == '__main__':
    train()
