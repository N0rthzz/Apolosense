import joblib
from pythainlp.tokenize import word_tokenize

def tokenize(text):
    return word_tokenize(text, engine='newmm')

def predict(text):
    model = joblib.load('models/apolosense_model.pkl')
    vectorizer = joblib.load('models/vectorizer.pkl')
    
    vec = vectorizer.transform([text])
    pred = model.predict(vec)[0]
    
    label_map = {1: 'จริงใจ', 0: 'ไม่จริงใจ'}
    return label_map[pred]

if __name__ == '__main__':
    sample = "ขอโทษจริงๆ ครับ จะไม่ทำอีกแล้ว"
    print(f'Input: {sample}')
    print(f'Result: {predict(sample)}')
